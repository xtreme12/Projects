package com.example.android.justjava;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;
import java.text.NumberFormat;
import java.util.zip.CheckedInputStream;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends ActionBarActivity {
    int quantity=2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    /**
     * This method displays the given price on the screen.
     */
    private void displayPrice(int number) {
        TextView priceTextView = (TextView) findViewById(R.id.price_text_view);
        priceTextView.setText(NumberFormat.getCurrencyInstance().format(number));
    }
    private void displayMessage(String message) {
        TextView orderSummaryTextView = (TextView) findViewById(R.id.order_summary_text_view);
        orderSummaryTextView.setText(message);
    }
    /**
     * This method is called when the plus button is clicked.
     */
    public void increment(View view) {

        if(quantity==100)
        {
            Toast.makeText(this,"You cannot have more than 100 coffees",Toast.LENGTH_SHORT).show();
            return;
        }
        quantity=quantity+1;
        display(quantity);
    }
    /**
     * This method is called when the minus button is clicked.
     */
    public void decrement(View view) {
if(quantity==1)
{
    Toast.makeText(this,"You cannot have less than 1 coffee",Toast.LENGTH_SHORT).show();
    return;
}
        quantity=quantity-1;
        display(quantity);
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void submitOrder(View view) {

        EditText nameField=(EditText) findViewById(R.id.name_field);
        String name=nameField.getText().toString();
        //Log.v("MainActivity","Name :"+name);

        CheckBox whippedCreamCheckBox= (CheckBox)findViewById(R.id.whipped_cream_checkbox);
        boolean hasWhippedCream = whippedCreamCheckBox.isChecked();

        CheckBox chocolateCheckBox= (CheckBox)findViewById(R.id.Chocolate_checkbox);
        boolean hasChocolate = chocolateCheckBox.isChecked();
       // Log.v("MainActivity","Has whipped cream  "+hasWhippedCream);
        int price=calculatePrice(hasWhippedCream,hasChocolate);
        String priceMessage=createOrderSummary(price,hasWhippedCream,hasChocolate,name);
        displayMessage(priceMessage);

  /*      Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("");
        intent.putExtra(Intent.EXTRA_EMAIL, "dishantahuja94@gmail.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, "My order app");
        intent.putExtra(Intent.EXTRA_STREAM, "I am an email body!");
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }*/

    }
private  int calculatePrice(boolean addWhippedCream,boolean addChocolate)
{
    int basePrice=5;

    if(addChocolate)
    {
        basePrice=basePrice+2;
    }
    if(addWhippedCream){
        basePrice=basePrice+1;
    }
    return quantity*basePrice;


}
    /**
     * This method displays the given quantity value on the screen.
     */
    private void display(int number) {
        TextView quantityTextView = (TextView) findViewById(
                R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }
    private String createOrderSummary(int price,boolean addWhippedCream,boolean addChocolate,String name)
    {
        String priceMessage="Name: "+name;
        priceMessage=priceMessage+"\nAdd whipped cream? "+addWhippedCream;
        priceMessage=priceMessage+"\nAdd chocolate? "+addChocolate;
        priceMessage=priceMessage+"\nQuantity: "+quantity;
        priceMessage=priceMessage+"\nTotal: Rs "+price;
        priceMessage=priceMessage+"\nThank you!";
        return priceMessage;
    }
}